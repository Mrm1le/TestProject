#pragma once

#include "core.h"

class pie_node
{
public:
    T* same;
    int TxProcess();
};
 
