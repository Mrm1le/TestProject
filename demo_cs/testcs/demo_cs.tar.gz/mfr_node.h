#pragma once

#include "core.h"

class mfr_node
{
public:
    T* same;
    int register_data(int a);
    // int same;
};
// int test11();
 
